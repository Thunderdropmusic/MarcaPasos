#include <Arduino.h>
#include <MIDI.h>
#include "MidiProgramming.h"
#include "menus_buttons.h"
#include "midiInterface.h"
#include "midiPresets.h"
#include "draw_menus.h"
#include "config.h"


// Declaración de la instancia
extern midi::MidiInterface<midi::SerialMIDI<HardwareSerial, HairlessConfig>> MIDI;

MidiProgramming midiProg[N_MAX_SEQS] = {
    MidiProgramming(0), 
    MidiProgramming(1), 
    MidiProgramming(2), 
    MidiProgramming(3), 
    MidiProgramming(4)
};
byte MidiProgramming::tipoMsgMidi = 0;
byte MidiProgramming::modeMidiClock = 0;
bool MidiProgramming::flagArmed[N_MAX_SEQS] = {false, false, false, false, false};

const byte smoothCurves[13][100] PROGMEM = {
  // Curva 0: Antiguamente Curva 7 (Logarítmica extrema)
  {0, 161, 173, 180, 185, 189, 193, 196, 198, 201, 203, 205, 206, 208, 210, 211, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 226, 227, 228, 228, 229, 230, 230, 231, 232, 232, 233, 233, 234, 235, 235, 236, 236, 237, 237, 238, 238, 239, 239, 240, 240, 240, 241, 241, 242, 242, 243, 243, 243, 244, 244, 244, 245, 245, 246, 246, 246, 247, 247, 247, 248, 248, 248, 249, 249, 249, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 253, 253, 253, 253, 254, 254, 254, 254, 255, 255},
  // Curva 1: Antiguamente Curva 8
  {0, 132, 146, 155, 161, 166, 171, 175, 178, 181, 184, 186, 189, 191, 193, 195, 197, 198, 200, 201, 203, 204, 206, 207, 208, 209, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 222, 223, 224, 225, 226, 226, 227, 228, 229, 229, 230, 231, 231, 232, 233, 233, 234, 234, 235, 236, 236, 237, 237, 238, 239, 239, 240, 240, 241, 241, 242, 242, 243, 243, 244, 244, 245, 245, 246, 246, 246, 247, 247, 248, 248, 249, 249, 250, 250, 250, 251, 251, 252, 252, 252, 253, 253, 254, 254, 254, 255, 255},
  // Curva 2: Antiguamente Curva 9
  {0, 102, 117, 127, 134, 140, 146, 150, 154, 158, 161, 164, 167, 170, 172, 175, 177, 179, 181, 183, 185, 187, 189, 190, 192, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207, 208, 209, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 222, 223, 224, 225, 226, 227, 228, 228, 229, 230, 231, 231, 232, 233, 234, 234, 235, 236, 237, 237, 238, 239, 239, 240, 241, 241, 242, 242, 243, 244, 244, 245, 246, 246, 247, 247, 248, 248, 249, 250, 250, 251, 251, 252, 252, 253, 253, 254, 254, 255},
  // Curva 3: Antiguamente Curva 10
  {0, 81, 96, 106, 114, 121, 127, 131, 136, 140, 144, 147, 150, 154, 156, 159, 162, 164, 167, 169, 171, 173, 175, 177, 179, 181, 183, 184, 186, 188, 189, 191, 192, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207, 208, 209, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 230, 231, 232, 233, 234, 235, 235, 236, 237, 238, 239, 239, 240, 241, 242, 243, 243, 244, 245, 245, 246, 247, 248, 248, 249, 250, 250, 251, 252, 252, 253, 254, 254, 255},
  // Curva 4: Antiguamente Curva 11
  {0, 55, 69, 80, 88, 94, 100, 105, 110, 115, 119, 123, 126, 130, 133, 136, 139, 142, 144, 147, 150, 152, 154, 157, 159, 161, 163, 165, 167, 169, 171, 173, 175, 177, 179, 180, 182, 184, 185, 187, 189, 190, 192, 193, 195, 196, 198, 199, 200, 202, 203, 204, 206, 207, 208, 210, 211, 212, 213, 215, 216, 217, 218, 219, 220, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 235, 236, 237, 238, 239, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 252, 253, 254, 255},
  // Curva 5: Antiguamente Curva 12 (Logarítmica suave)
  {0, 26, 36, 44, 51, 57, 63, 68, 72, 77, 81, 85, 89, 92, 96, 99, 103, 106, 109, 112, 115, 117, 120, 123, 126, 128, 131, 133, 136, 138, 140, 143, 145, 147, 149, 152, 154, 156, 158, 160, 162, 164, 166, 168, 170, 172, 174, 176, 178, 179, 181, 183, 185, 187, 188, 190, 192, 193, 195, 197, 199, 200, 202, 203, 205, 207, 208, 210, 211, 213, 214, 216, 217, 219, 220, 222, 223, 225, 226, 228, 229, 231, 232, 233, 235, 236, 238, 239, 240, 242, 243, 244, 246, 247, 248, 250, 251, 252, 254, 255},
  // Curva 6: Antiguamente Curva 0 (Lineal PURA - El Centro)
  {0, 3, 5, 8, 10, 13, 15, 18, 21, 23, 26, 28, 31, 33, 36, 39, 41, 44, 46, 49, 52, 54, 57, 59, 62, 64, 67, 70, 72, 75, 77, 80, 82, 85, 88, 90, 93, 95, 98, 100, 103, 106, 108, 111, 113, 116, 118, 121, 124, 126, 129, 131, 134, 137, 139, 142, 144, 147, 149, 152, 155, 157, 160, 162, 165, 167, 170, 173, 175, 178, 180, 183, 185, 188, 191, 193, 196, 198, 201, 203, 206, 209, 211, 214, 216, 219, 222, 224, 227, 229, 232, 234, 237, 240, 242, 245, 247, 250, 252, 255},
  // Curva 7: Antiguamente Curva 1 (Exponencial suave)
  {0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 6, 7, 8, 8, 9, 10, 11, 13, 14, 15, 16, 18, 19, 20, 22, 23, 25, 27, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 53, 55, 57, 60, 62, 65, 68, 70, 73, 76, 79, 82, 85, 88, 91, 94, 97, 100, 103, 107, 110, 113, 117, 120, 124, 127, 131, 135, 139, 142, 146, 150, 154, 158, 162, 167, 171, 175, 179, 184, 188, 192, 197, 201, 206, 211, 215, 220, 225, 230, 235, 240, 245, 250, 255},
  // Curva 8: Antiguamente Curva 2
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 9, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 24, 26, 27, 29, 31, 33, 35, 37, 39, 41, 44, 46, 49, 51, 54, 57, 60, 63, 66, 69, 72, 76, 79, 83, 86, 90, 94, 98, 102, 106, 111, 115, 120, 125, 130, 135, 140, 145, 150, 156, 161, 167, 173, 179, 185, 192, 198, 205, 211, 218, 225, 233, 240, 247, 255},
  // Curva 9: Antiguamente Curva 3
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 4, 5, 6, 6, 7, 8, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 21, 23, 24, 26, 28, 30, 32, 34, 37, 39, 42, 45, 47, 50, 53, 57, 60, 64, 67, 71, 75, 80, 84, 89, 93, 98, 103, 109, 114, 120, 126, 132, 139, 145, 152, 159, 167, 174, 182, 190, 199, 207, 216, 225, 235, 245, 255},
  // Curva 10: Antiguamente Curva 4
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 4, 5, 6, 6, 7, 8, 8, 9, 10, 11, 12, 13, 15, 16, 18, 19, 21, 23, 25, 27, 29, 31, 34, 36, 39, 42, 45, 48, 52, 56, 60, 64, 68, 73, 77, 83, 88, 93, 99, 106, 112, 119, 126, 134, 142, 150, 158, 167, 177, 187, 197, 207, 219, 230, 242, 255},
  // Curva 11: Antiguamente Curva 5
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 17, 18, 20, 23, 25, 27, 30, 33, 37, 40, 44, 48, 53, 57, 63, 68, 74, 81, 88, 95, 103, 112, 121, 131, 141, 153, 165, 177, 191, 206, 221, 238, 255},
  // Curva 12: Antiguamente Curva 6 (Exponencial extrema)
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 5, 6, 7, 8, 9, 11, 12, 14, 16, 18, 21, 24, 27, 30, 34, 39, 44, 49, 56, 62, 70, 79, 88, 98, 110, 122, 136, 152, 169, 187, 208, 230, 255}
};

const byte MidiProgramming::escalasNotas[5][13]{
  {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}, //Escala cromática
  {0, 2, 3, 5, 7, 8, 10, 12, 0, 0, 0, 0, 0}, //Escala menor Natural
  {0, 2, 4, 5, 7, 9, 11, 12, 0, 0, 0, 0, 0}, //Escala Mayor
  {0, 2, 4, 6, 8, 10, 12, 0, 0, 0, 0, 0, 0}, //Escala de tonos
  {0, 1, 3, 4, 6, 7, 9, 10, 12, 0, 0, 0, 0} //Escala Semitono-tono
};

const byte MidiProgramming::subdivisionesArray[12] {3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96};

const byte MidiProgramming::subdivisionesComplejasArray[3][6] {
  {5, 7, 9, 11, 13, 15},
  {10, 14, 18, 22, 26, 30},
  {20, 28, 36, 0, 0, 0,}
};
const byte MidiProgramming::nNotasEscalas[5]{13, 8, 8, 7, 9};

MidiProgramming::MidiProgramming(byte _id) : 
  id(_id)


  //variables MIDI y notas
{
  decay = 250;
  microsSubdivision = 50000000;
  tempo = 120;
  tempoMicros = int(60000000/(tempo*24.0));
}

// ==============================================================================
//                               FUNCIONES UTILES
// ==============================================================================

void MidiProgramming::initMode(){
  notaExterna = 0;
  nClockMsg = 0;
  pulsoClock = 0;
  tiempoClock1 = 0;
  tiempoClock2 = 0;
  lecturaPulsoClock = 24;
  primeraMedicionSubCompleja = true;
  nStep = 0;
  microsSubdivision = 0;
}

void MidiProgramming::initValues(){
  notaFuera = false;
  play = true;
  nClockMsg = 0;
  pulsoClock = 0;
  tiempoClock1 = 0;
  tiempoClock2 = 0;
  lecturaPulsoClock = 24;
  primeraMedicionSubCompleja = true;
  nStep = 0;
}

void MidiProgramming::syncWithActiveSequence() {
  s = presetsUI.getPlayedSequence(id);
  stp = inExtension ? p->nSequence[id].ext_steps : p->nSequence[id].steps;

  curTotalSteps = inExtension ? p->nSequence[id].ext_nTotalSteps : p->nSequence[id].nTotalSteps;
  curSubdivMode = inExtension ? p->nSequence[id].ext_subdivMode : p->nSequence[id].subdivMode;
  curIndSubdiv  = inExtension ? p->nSequence[id].ext_indexSubdivisiones : p->nSequence[id].indexSubdivisiones;
  curindComplexSubdivY = inExtension ? p->nSequence[id].ext_indComplexSubdivY : p->nSequence[id].indComplexSubdivY;
  curindComplexSubdivX = inExtension ? p->nSequence[id].ext_indComplexSubdivX : p->nSequence[id].indComplexSubdivX;
}

// ==============================================================================
//                         FUNCIÓN PRINCIPAL (midiSeq)
// ==============================================================================

void MidiProgramming::midiSeq(){
  syncWithActiveSequence();

  if(midiUI.deviceFlagPlay && pulsoClock == 24){
    midiUI.deviceFlagPlay = false;
    midiUI.devicePlay = true;
    for(int i = 0; i < N_MAX_SEQS; i++){
      midiProg[i].initValues();
    }
  }
  else if(tipoMsgMidi == 0xFA){ //Start
    if(modeMidiClock == 1){
      MIDI.sendRealTime(midi::Start);
    }
    initValues();
    if(curSubdivMode == 2){
      microsSubdivision = 0;
    }
    else{subdivision = subdivisionesArray[curIndSubdiv];
    }
  }
  else if(tipoMsgMidi == 0xF8){ // Pulsación
    if(curSubdivMode == 0 || curSubdivMode == 1){ // Modo global - binario
      modo01Subdivision();
    }
    else if(curSubdivMode == 2){ // Modo complejo
      modo2Subdivision();
    }
  }
  else if(tipoMsgMidi == 0xFC){ //Stop
    play = false;
    if(modeMidiClock == 1){MIDI.sendRealTime(midi::Stop);}
  }
  else if((tipoMsgMidi & 0xF0) == 0x90){
    notaExterna = MIDI.getData1() % 24;
  }
}

// ==============================================================================
//                         PROCESAMIENTO SEGÚN SUBDIVISIÓN
// ==============================================================================

void MidiProgramming::modo01Subdivision(){
    // --- RESETEO DE LA PULSACIÓN / ACTUALIZACIÓN DE LA SUBDIVISION ---
  if (subdivision < 16 || subdivision == 24){
    if(pulsoClock == 24){
      pulsoClock = 0, subdivision = subdivisionesArray[curIndSubdiv], nClockMsg = 0;
      if(flagArmed[id]){
        p->nSequence[id].armed = true;
        flagArmed[id] = false;
      }
    }
  }
  else{
    // Si armamos una secuencia en mitad de la reproducción, esta se sincronizará a la redonda
    if(pulsoClock == 96){
      pulsoClock = 0, subdivision = subdivisionesArray[curIndSubdiv], nClockMsg = 0;
      if(flagArmed[id]){
        p->nSequence[id].armed = true;
        flagArmed[id] = false;
      }
    }
  }
  // Si cambiamos de modo en mitad de la reproducción, esta se hara efectiva cuando el pulso sea 0
  if(menusUI.cambioModo2[id] && pulsoClock == 0){
    curSubdivMode = 2;
    initMode();
    menusUI.cambioModo2[id] = false;
    drawUI.updateLCD = true;
    modo2Subdivision();
    return;
  }

  nClockMsg++;
  pulsoClock++;
  // Si es igual, calculamos todos los parametros de la nota a enviar
  if (nClockMsg == subdivision){
    decay = 10*subdivision; // Calculamos el decay
    nClockMsg = 0;
    nStep ++;
    // Si estamos al final de la secuencia y si está la extensión activada, procederemos a reproducir la extensión
    if (nStep > curTotalSteps - 1){
      nStep = 0;
      if (p->nSequence[id].extensionArmed) {
        inExtension = !inExtension;
      }
      else {inExtension = false;}
      stp = inExtension ? p->nSequence[id].ext_steps : p->nSequence[id].steps;
      curTotalSteps = inExtension ? p->nSequence[id].ext_nTotalSteps : p->nSequence[id].nTotalSteps;
      curSubdivMode = inExtension ? p->nSequence[id].ext_subdivMode : p->nSequence[id].subdivMode;
      curIndSubdiv = inExtension ? p->nSequence[id].ext_indexSubdivisiones : p->nSequence[id].indexSubdivisiones;
      curindComplexSubdivY = inExtension ? p->nSequence[id].ext_indComplexSubdivY : p->nSequence[id].indComplexSubdivY;
      curindComplexSubdivX = inExtension ? p->nSequence[id].ext_indComplexSubdivX : p->nSequence[id].indComplexSubdivX;
      if(curSubdivMode == 0 || curSubdivMode == 1){subdivision = subdivisionesArray[curIndSubdiv];}
      else{subdivision = subdivisionesComplejasArray[curindComplexSubdivY][curindComplexSubdivX];}
      pulsoClock = 0;
      nClockMsg = 0;
    }
  }
}

void MidiProgramming::modo2Subdivision(){
  // Si cambiamos de modo en mitad de la reproducción, esta se hara efectiva cuando el pulso sea 0
  if(menusUI.cambioModo0[id] && pulsoClock == 0){
    curSubdivMode = 0;
    initMode();
    menusUI.cambioModo0[id] = false;
    drawUI.updateLCD = true;
    modo01Subdivision();
    return;
  }
  if(menusUI.cambioModo1[id] && pulsoClock == 0){
    curSubdivMode = 1;
    initMode();
    menusUI.cambioModo1[id] = false;
    drawUI.updateLCD = true;
    modo01Subdivision();
    return;
  }

  nClockMsg++;
  // Si estamos en un pulso nuevo, recalcularemos el valor en microsegundos de la nota
  if(pulsoClock == 0){
    subdivision = subdivisionesComplejasArray[curindComplexSubdivY][curindComplexSubdivX];
    tiempoClock1 = micros();
    // Para hacer un primer calculo, el primer pulso debe ser de medición.
    if (tiempoClock2 != 0 && nClockMsg > 1) { 
      sumaTiempos = tiempoClock1 - tiempoClock2; // tiempo exacto que dura una regicn (1ª medicion = negra / resto = redonda)
      if(primeraMedicionSubCompleja){ microsSubdivision = sumaTiempos*4 / subdivision; }
      else{ microsSubdivision = sumaTiempos / subdivision; } // Cuanto debe durar cada nota en microsegundos

      tiempoUltimaNota = tiempoClock1;
      primerPulso = true;
      primeraMedicionSubCompleja = false;
    }
    tiempoClock2 = tiempoClock1;
  } 

  pulsoClock++;
  if(pulsoClock >= lecturaPulsoClock){
    pulsoClock = 0;
    lecturaPulsoClock = 96; // despues de la primera medición, cambiamos el valor a 96 para leer la redonda
  }
}

// ==============================================================================
//                                 ENVÍO DE NOTAS
// ==============================================================================

void MidiProgramming::midiNotesOn(){
  // --- MODO DE SUBDIVISION GLOBAL O BINARIA ---
  if(play == true && !notaFuera && (curSubdivMode == 0 || curSubdivMode == 1)){
    if (nClockMsg == 0){ 
      notaFuera = true;
      if(!stp[nStep].mutes){
        MIDI.sendNoteOn(stp[nStep].note + (12 * stp[nStep].octave) + notaExterna, stp[nStep].velocity, id + 1);
        notaTocada = stp[nStep].note + 12 * stp[nStep].octave + notaExterna;
      }
      timeDecayNote = millis();
    }
  }
  // --- MODO DE SUBDIVISION COMPLEJA ---
  else if(play == true && curSubdivMode == 2){
    // Primera medidcion
    if(primerPulso){ 
      tiempoUltimaNota = tiempoClock1;
      primerPulso = false; 
      dispararNotaMode2();
    }
    // Resto
    else if (microsSubdivision >= 10000 && (tiempoActualMicros - tiempoUltimaNota > microsSubdivision)){ // Para evitar ametrallamiento de notas
      unsigned long tiempoDesdeInicioRedonda = tiempoActualMicros - tiempoClock1; // Tiempo real que ha durado la redonda
      unsigned long duracionRedondaTeorica = microsSubdivision * subdivision; // Cuanto debería durar exactamente
      if (tiempoDesdeInicioRedonda < (duracionRedondaTeorica - 15000)) {
        tiempoUltimaNota += microsSubdivision; // Sumamos el offset para evitar el jitter
        dispararNotaMode2();
      }
    }
  }
}

// --- DISPARO MODO 2 ---
void MidiProgramming::dispararNotaMode2(){ 
  notaFuera = true;
  if(!stp[nStep].mutes){
    MIDI.sendNoteOn(stp[nStep].note + (12 * stp[nStep].octave) + notaExterna, stp[nStep].velocity, id + 1);
  }

  // Calculo del decay
  decay = (microsSubdivision/2000);
  notaTocada = stp[nStep].note + 12 * stp[nStep].octave + notaExterna;
  timeDecayNote = millis();

  // Actualización del paso
  nStep ++;
  if (nStep > curTotalSteps - 1){
    nStep = 0;
    if (p->nSequence[id].extensionArmed) {
      inExtension = !inExtension;
    }
    else {inExtension = false;}
    stp = inExtension ? p->nSequence[id].ext_steps : p->nSequence[id].steps;
    curTotalSteps = inExtension ? p->nSequence[id].ext_nTotalSteps : p->nSequence[id].nTotalSteps;
    curSubdivMode = inExtension ? p->nSequence[id].ext_subdivMode : p->nSequence[id].subdivMode;
    curIndSubdiv = inExtension ? p->nSequence[id].ext_indexSubdivisiones : p->nSequence[id].indexSubdivisiones;
    curindComplexSubdivY = inExtension ? p->nSequence[id].ext_indComplexSubdivY : p->nSequence[id].indComplexSubdivY;
    curindComplexSubdivX = inExtension ? p->nSequence[id].ext_indComplexSubdivX : p->nSequence[id].indComplexSubdivX;
    if(curSubdivMode == 0 || curSubdivMode == 1){subdivision = subdivisionesArray[curIndSubdiv];}
    else{subdivision = subdivisionesComplejasArray[curindComplexSubdivY][curindComplexSubdivX];}
    pulsoClock = 0;
    nClockMsg = 0;
  }
}

// --- APAGADO DE NOTAS ---
void MidiProgramming::midiNotesOff(){
  if (notaFuera && (millis() - timeDecayNote >= decay)){
    MIDI.sendNoteOff(notaTocada, 0, id + 1);
    notaFuera = false;
    timeDecayNote = 0;
  }
}

// ==============================================================================
//                             FUNCIONES MODO CC
// ==============================================================================

void MidiProgramming::CCSend(){
  if(!play) return;
  else if (tipoMsgMidi != 0xF8 && tipoMsgMidi != 0xFA) return;
  
  if (nClockMsg == 0) { 
    // FASE DE CÁLCULO: Se ejecuta solo en el primer pulso de cada Step
    nMsgCC[id] = 0;
    int totalSteps = curTotalSteps;

    // Buscar el punto desde el que partimos
    int prevStep = nStep;
    int countBack = 0;
    while (countBack < totalSteps) {
      if (!stp[prevStep].ccMutes) { // Byscamos el primer valor no muteado
        break;
      }
      prevStep--;
      if (prevStep < 0) {prevStep = totalSteps - 1;} // Si prevStep alcanza el -1, el paso seguirá contando desde el número máximo de pasos
      countBack++;
    }

    // Mirar hacia adelante y encontrar el primer punto que no esté muteado
    int nextStep = nStep + 1;
    if (nextStep >= totalSteps) nextStep = 0;
    int countForward = 0;
    while (countForward < totalSteps) {
      if (!stp[nextStep].ccMutes) {
        break;
      }
      nextStep++;
      if (nextStep >= totalSteps) nextStep = 0; // Si prevStep alcanza al número maximo de pasos, nextStep seguirá contando desde 0
      countForward++;
    }

    // Recogemos los valores de los dos puntos y su distancia entre ellos
    int valorActual = stp[prevStep].ccValue;
    int valorSiguiente = stp[nextStep].ccValue;
    int ccStepSize = valorSiguiente - valorActual; // Distancia total entre los dos mensajes

    // Distancia total entre los dos puntos a interpolar
    int distanceSteps = 0;
    if (nextStep > prevStep) {distanceSteps = nextStep - prevStep;} 
    else if (nextStep < prevStep) {distanceSteps = (totalSteps - prevStep) + nextStep;} 
    else {distanceSteps = totalSteps;}

    // Punto en el que nos encontramos actualmente (nStep) en cuanto a pasos
    int offsetSteps = 0;
    if (nStep >= prevStep) {offsetSteps = nStep - prevStep;} 
    else {offsetSteps = (totalSteps - prevStep) + nStep;}

    // Convertimos esos datos a pulsos de reloj midi
    int subdivisionActual = distanceSteps * subdivision; // Valores totales a calcular entre los dos puntos
    int offset = offsetSteps * subdivision; // Punto en el que nos encontramos actualmente en mensajes midi
    int divisor = (subdivisionActual > 1) ? subdivisionActual : 2; // Seguridad: El divisor mínimo es 2 para evitar divisiones por cero en ccCurveFunction

    // Calculo de la curva por cada punto de la subidivision. offset es cuanto 
    for(int i = 0; i < subdivision; i++) {
      int indexCurva = offset + i;
      // vamos calculando cada valor de la curva según el tamaño entre pasos.
      // Aplicamos la fórmula: V = V_inicio + ((Delta * %_Curva) / 255)
      long valorCurva = ccCurveFunction(indexCurva, divisor, stp[prevStep].ccSmoothCurve);
      CCinterpolation[i] = valorActual + (((long)ccStepSize * valorCurva) / 255); // 255 es el tamaño maximo de un byte
    }
  }
  else {
    nMsgCC[id]++;
  }
  
  MIDI.sendControlChange(p->nSequence[id].ccNumber, CCinterpolation[nMsgCC[id]], id + 1);
}

int MidiProgramming::ccCurveFunction(int i, int subdivisionActual, int tensionMode){
  // Mapeador para calcular los puntos que dure la curva. 
  // i = punto de la curva; 99 = tamaño de la tabla; subdivision actual = cuan largo es el paso
  int indiceLUT = (i * 99) / (subdivisionActual - 1);
  byte factorCurva = pgm_read_byte(&(smoothCurves[tensionMode][indiceLUT])); //pgm_read_byte es porque la tabla la tenemos en la memoria flash
  return factorCurva;
}